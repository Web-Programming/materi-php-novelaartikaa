

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Prodi</h2>
    <form action="<?php echo e(url('prodi/' . $prodi->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>

        <div class="form-group">
            <label for="nama">Nama Prodi</label>
            <input type="text" class="form-control" id="nama" name="nama"
                   value="<?php echo e(old('nama', $prodi->nama)); ?>" required>
        </div>

        <div class="form-group">
            <label for="kode_prodi">Kode Prodi</label>
            <input type="text" class="form-control" id="kode_prodi" name="kode_prodi"
                   value="<?php echo e(old('kode_prodi', $prodi->kode_prodi)); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PAW1\materi-php-novelaartikaa\Latihan\resources\views/prodi/edit.blade.php ENDPATH**/ ?>