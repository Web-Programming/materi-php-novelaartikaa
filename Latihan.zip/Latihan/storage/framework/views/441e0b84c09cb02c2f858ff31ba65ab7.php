<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE-4.0.0-beta3/dist/css/adminlte.min.css')); ?>">
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        
        <?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

    <!-- AdminLTE JS -->
    <script src="<?php echo e(asset('AdminLTE-4.0.0-beta3/dist/js/adminlte.min.js')); ?>"></script>
</body>
</html>

<?php /**PATH C:\PAW1\materi-php-novelaartikaa\Latihan\resources\views/layout/master.blade.php ENDPATH**/ ?>