<h1>Welcome to Login Page</h1>
<h2>Hallo 
    <?php echo e($name); ?>

</h2>
<h2>Ur Email 
    <?php echo e($email); ?>

</h2>
<h2>Ur Adress 
    <?php echo e($alamat); ?>

</h2><?php /**PATH C:\PAW1\materi-php-novelaartikaa\Latihan\resources\views/login.blade.php ENDPATH**/ ?>