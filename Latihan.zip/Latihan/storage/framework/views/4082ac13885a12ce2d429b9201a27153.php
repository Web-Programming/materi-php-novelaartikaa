<div>
<p>ID Berita: <?php echo e($id); ?></p>
<p>judul: <?php echo e($judul); ?></p>
</div><?php /**PATH C:\PAW1\materi-php-novelaartikaa\Latihan\resources\views/berita.blade.php ENDPATH**/ ?>