@extends('layout.master')

@section('title', 'Halaman Dosen')

@section('content')
    <h1>Ini adalah halaman dosen</h1>
@endsection
