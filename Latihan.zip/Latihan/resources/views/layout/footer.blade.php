<div>
    <!-- Very little is needed to make a happy life. - Marcus Aurelius -->
</div>
