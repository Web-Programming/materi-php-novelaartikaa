<!-- Main Footer -->
<footer class="main-footer">
  <strong>&copy; 2025 Universitas Contoh.</strong> All rights reserved.
</footer>
